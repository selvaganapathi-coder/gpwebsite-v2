import 'dotenv/config'
import { createApp } from './app.js'

const PORT = Number(process.env.PORT) || 3001
const baseUrl = process.env.PUBLIC_URL || `http://localhost:${PORT}`

const app = await createApp()
app.listen(PORT, () => {
  console.log(`GP Pharmacy CMS running at ${baseUrl}`)
  console.log(`Admin: ${baseUrl}/admin`)
  console.log(`API:   ${baseUrl}/api/health`)
})
