import express from 'express'
import cors from 'cors'
import multer from 'multer'
import path from 'path'
import { fileURLToPath } from 'url'
import { authMiddleware, authenticateUser, ensureDefaultUsers, signToken } from './auth.js'
import { getPublicContent, loadStoreAsync, saveStoreAsync } from './store.js'
import { ensureUploadDir, uploadImage, getUploadedFile } from './upload.js'

function resolveDirname() {
  try {
    if (typeof import.meta?.url === 'string' && import.meta.url) {
      return path.dirname(fileURLToPath(import.meta.url))
    }
  } catch {
    /* bundled CJS */
  }
  return path.join(process.cwd(), 'server')
}

const __dirname = resolveDirname()

/**
 * Create the CMS Express app.
 * `getStore` / `setStore` keep an in-process cache so serverless invocations stay coherent
 * within a warm instance; Blobs persist across cold starts on Netlify.
 */
export async function createApp() {
  let store = await loadStoreAsync()
  await ensureDefaultUsers(store)
  store = await saveStoreAsync(store)
  ensureUploadDir()

  const app = express()
  const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 5 * 1024 * 1024 },
  })

  const origins = (
    process.env.CORS_ORIGINS ||
    'http://localhost:3001,http://localhost:8080,http://localhost:5173,http://127.0.0.1:5173'
  )
    .split(',')
    .map((value) => value.trim())
    .filter(Boolean)

  const allowAllNetlify = process.env.NETLIFY === 'true' || process.env.ALLOW_NETLIFY_ORIGINS === '1'

  app.use(
    cors({
      origin(origin, cb) {
        if (!origin) return cb(null, true)
        if (origins.includes(origin)) return cb(null, true)
        if (allowAllNetlify && /\.netlify\.app$/i.test(origin)) return cb(null, true)
        return cb(null, false)
      },
      credentials: true,
    }),
  )
  app.use(express.json({ limit: '2mb' }))

  const baseUrl = process.env.PUBLIC_URL || process.env.URL || `http://localhost:${process.env.PORT || 3001}`

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, updatedAt: store.updatedAt })
  })

  app.get('/api/content/public', (_req, res) => {
    res.json(getPublicContent(store))
  })

  app.get('/api/content', authMiddleware, (_req, res) => {
    const copy = structuredClone(store)
    copy.users = (copy.users || []).map(({ passwordHash, ...user }) => user)
    res.json(copy)
  })

  app.put('/api/content', authMiddleware, async (req, res) => {
    if (!req.body || typeof req.body !== 'object') {
      res.status(400).json({ error: 'Invalid content payload.' })
      return
    }

    const incomingUsers = req.body.users
    const next = { ...store, ...req.body, users: store.users }
    if (Array.isArray(incomingUsers) && req.user.role === 'admin') {
      next.users = incomingUsers.map((user) => {
        const existing = store.users.find((item) => item.id === user.id)
        return existing?.passwordHash ? { ...user, passwordHash: existing.passwordHash } : user
      })
    }

    store = await saveStoreAsync(next)
    res.json({ ok: true, updatedAt: store.updatedAt })
  })

  app.post('/api/auth/login', async (req, res) => {
    const { email, password } = req.body || {}
    if (!email || !password) {
      res.status(400).json({ error: 'Email and password are required.' })
      return
    }

    const user = await authenticateUser(store, String(email).trim(), String(password))
    if (!user) {
      res.status(401).json({ error: 'Invalid email or password.' })
      return
    }

    res.json({
      token: signToken(user),
      user: { id: user.id, name: user.name, email: user.email, role: user.role },
    })
  })

  app.post('/api/upload', authMiddleware, upload.single('file'), async (req, res) => {
    if (!req.file) {
      res.status(400).json({ error: 'No file uploaded.' })
      return
    }
    if (!req.file.mimetype?.startsWith('image/')) {
      res.status(400).json({ error: 'Only image files are allowed.' })
      return
    }

    try {
      const url = await uploadImage(req.file, baseUrl)
      res.json({ url })
    } catch (error) {
      res.status(500).json({ error: error.message || 'Upload failed.' })
    }
  })

  app.get('/uploads/:name', async (req, res) => {
    try {
      const file = await getUploadedFile(req.params.name)
      if (!file) {
        res.status(404).json({ error: 'Not found' })
        return
      }
      res.setHeader('Content-Type', file.contentType || 'application/octet-stream')
      res.setHeader('Cache-Control', 'public, max-age=2592000')
      res.send(file.body)
    } catch {
      res.status(404).json({ error: 'Not found' })
    }
  })

  // Local Node also serves legacy static HTML from repo root
  if (!process.env.NETLIFY) {
    const siteRoot = path.join(__dirname, '..')
    app.use('/uploads', express.static(path.join(__dirname, 'uploads')))
    app.use(express.static(siteRoot))
  }

  return app
}
