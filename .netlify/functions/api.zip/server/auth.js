import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'gp-cms-dev-secret-change-me';
const JWT_EXPIRY = '8h';

export async function hashPassword(password) {
  return bcrypt.hash(password, 10);
}

export async function verifyPassword(password, hash) {
  return bcrypt.compare(password, hash);
}

export function signToken(user) {
  return jwt.sign(
    { sub: user.id, email: user.email, role: user.role, name: user.name },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRY },
  );
}

export function authMiddleware(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) {
    res.status(401).json({ error: 'Authentication required.' });
    return;
  }
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Session expired. Please sign in again.' });
  }
}

export async function ensureDefaultUsers(store) {
  if (store.users?.length) return store;

  store.users = [
    {
      id: 'user-admin',
      name: 'GP Admin',
      email: 'admin@gppharmacycollege.com',
      passwordHash: await hashPassword('gpadmin2026'),
      role: 'admin',
      active: true,
      createdAt: '2026-01-01',
    },
    {
      id: 'user-editor',
      name: 'Content Editor',
      email: 'editor@gppharmacycollege.com',
      passwordHash: await hashPassword('editor2026'),
      role: 'editor',
      active: true,
      createdAt: '2026-01-01',
    },
  ];
  return store;
}

export async function authenticateUser(store, email, password) {
  const user = store.users?.find((u) => u.email === email && u.active);
  if (!user?.passwordHash) return null;
  const valid = await verifyPassword(password, user.passwordHash);
  if (!valid) return null;
  return user;
}
