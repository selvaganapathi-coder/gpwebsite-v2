import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

function resolveDirname() {
  try {
    if (typeof import.meta?.url === 'string' && import.meta.url) {
      return path.dirname(fileURLToPath(import.meta.url));
    }
  } catch {
    /* bundled CJS */
  }
  return path.join(process.cwd(), 'server');
}

const __dirname = resolveDirname();
const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'cms.json');

const GP_ASSETS = 'https://gppharmacycollege.com/wp-content/uploads/2025/03';

export const DEFAULTS = {
  version: 1,
  updatedAt: null,
  users: [],
  site: {
    name: 'G.P. Pharmacy College',
    tag: 'Tirupattur · Code 889',
    code: '889',
    logo: 'https://gppharmacycollege.com/wp-content/uploads/2025/03/GP-Logo-neww.png',
    logoMark: 'https://gppharmacycollege.com/wp-content/uploads/2025/03/cropped-GP-Logo-32x32.png',
    phone: '+919443437487',
    phoneDisplay: '+91 94434 37487',
    phoneAlt: '+919578627535',
    phoneAltDisplay: '+91 95786 27535',
    email: 'gppharmacycollege@gmail.com',
    principalEmail: 'drthenmozhish@gmail.com',
    address: 'Vaniyambadi Main Road, Mandalavadi (Vill&Po), Jolarpet – 635851',
    whatsapp: '919443437487',
    aicte: '1-4713123911',
    pci: '3030',
    mapsPlaceUrl:
      'https://www.google.com/maps/place/GP+PHARMACY+COLLEGE/@12.612339,78.599926,17z',
    mapsEmbedUrl:
      'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d7787.086099929674!2d78.599926!3d12.612339!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3badab4e2f3777b5%3A0xa2842979384d8d57!2sGP%20PHARMACY%20COLLEGE!5e0!3m2!1sen!2sin!4v1741348488285!5m2!1sen!2sin',
  },
  website: {
    homepage: {
      published: true,
      badge: 'AICTE & PCI Approved · Counselling Code 889',
      title: 'G.P. Pharmacy College',
      subtitle: 'Excellence in Pharmacy Education',
      slides: [
        `${GP_ASSETS}/G.P-Pharmacy-College-home.jpg`,
        `${GP_ASSETS}/G.P-Pharmacy-College-home2.jpg`,
        `${GP_ASSETS}/G.P.Pharmacy-College5.jpg`,
      ],
      announcement:
        'Counselling Code 889 · AICTE (1-4713123911) & PCI (3030) · TN G.O (Ms) 460 & 464 · Affiliated to The Tamil Nadu Dr. M.G.R. Medical University',
      homeAbout: {
        eyebrow: 'Our College',
        title: 'About G.P. Pharmacy',
        badge: 'Est. 2019',
        image: `${GP_ASSETS}/G.P.Pharmacy-College26.jpg`,
        facts: [
          'First pharmacy college in Tirupattur & Vellore District',
          'Established 2019 · Counselling Code 889',
          'AICTE & PCI approved · TN Dr. M.G.R. Medical University',
        ],
        ctaPrimary: 'About the college →',
        ctaSecondary: 'Talk to Admin →',
      },
      campusShow: {
        eyebrow: 'On Campus',
        title: 'Labs · Library · Hostel',
        lead: 'Real spaces where pharmacy learning happens every day.',
        items: [
          { id: 'lab', title: 'Lab', caption: 'Hands-on pharmaceutical training', image: `${GP_ASSETS}/Pharmaceutics-lab.jpg` },
          { id: 'library', title: 'Library', caption: 'Quiet study · AC resources', image: `${GP_ASSETS}/G.P.-Pharmacy-College-Library.jpg` },
          { id: 'hostel', title: 'Hostel', caption: 'Separate boys & girls facilities', image: `${GP_ASSETS}/G.P.Pharmacy-College28.jpg` },
        ],
      },
      people: {
        eyebrow: 'Our People',
        title: 'Meet the college',
        lead: 'Leadership and faculty parents can put a face to.',
        slots: [
          { id: 'chairman', name: 'Er. G. Ponnusamy', role: 'Chairman · GP Group', image: `${GP_ASSETS}/G.P.Pharmacy-Chairman.jpg`, href: '/about/management' },
          { id: 'principal', name: 'Prof. Dr. S. Thenmozhi', role: 'Principal · M.Pharm., Ph.D', image: 'images/about/about-principal.png', href: '/about/principal' },
          { id: 'fac-1', name: 'Dr. P. Harini', role: 'Professor · Pharmaceutics', image: '', href: '' },
          { id: 'fac-2', name: 'Dr. K. Anand', role: 'Assoc. Professor · Analysis', image: '', href: '' },
        ],
        moreLabel: 'Faculty & students',
        moreCaption: 'View full directory →',
        moreImage: `${GP_ASSETS}/G.P.Pharmacy-College12.jpg`,
        moreHref: '/faculty',
      },
      outcomes: {
        eyebrow: 'After GP',
        title: 'Pharmacy careers',
        items: [
          { id: 'hospital', label: 'Hospital', desc: 'Clinical & hospital pharmacy roles' },
          { id: 'industry', label: 'Industry', desc: 'Production, QA & regulatory paths' },
          { id: 'retail', label: 'Retail', desc: 'Community pharmacy & entrepreneurship' },
        ],
        linkText: 'Talk to Admin →',
        linkHref: '/contact',
      },
      campusTour: {
        youtubeUrl: 'https://youtu.be/oIsIJ6LxVQc',
        lead: 'A quick look at labs, library and grounds — then visit Jolarpet in person.',
        fallbackImage: `${GP_ASSETS}/G.P-Pharmacy-College-home.jpg`,
      },
      approvals: [
        { id: 'code', title: '889', subtitle: 'Counselling Code', href: '/admissions', linkLabel: 'Talk to Admin →', variant: 'code' },
        { id: 'aicte', title: 'AICTE', subtitle: 'Approved', href: '/mandatory-disclosure' },
        { id: 'pci', title: 'PCI', subtitle: 'Approved', href: '/mandatory-disclosure' },
        { id: 'univ', title: 'TN MGR', subtitle: 'University affiliation', href: '/mandatory-disclosure' },
        { id: 'disclosure', title: 'Disclosure', subtitle: 'Mandatory public info', href: '/mandatory-disclosure' },
      ],
    },
    about: {
      published: true,
      heroTitle: 'About Us',
      heroSubtitle: 'First pharmacy college in Tirupattur & Vellore District · Established 2019',
      discoverTitle: 'GP Group — Education for Every Community',
      discoverProse: [
        'Our Chairman Er. G. Ponnusamy, B.E., educationist, has provided quality education to middle-class and underserved communities since 1979 — starting with ITI, then Tirupattur Arts and Science College, GP Polytechnic, GP College of Education, and G.P. Pharmacy College.',
        'G.P. Pharmacy College, established in 2019, is the first pharmacy college in Tirupattur and the entire Vellore District. Affiliated to The Tamil Nadu Dr. M.G.R. Medical University and approved by AICTE & PCI, we offer D.Pharm, B.Pharm, M.Pharm and Pharm-D with modern labs, digital classrooms, AC library, hostels, and strong career support.',
      ],
      discoverImage: `${GP_ASSETS}/gp-pharma-home-right1.jpg`,
      highlights: [
        { title: 'Experienced Faculty', desc: 'Real-world expertise and deep subject knowledge guiding every student.', image: `${GP_ASSETS}/G.P.Pharmacy-College22.jpg` },
        { title: 'Smart Classrooms', desc: 'Interactive digital tools for dynamic, engaging theory sessions.', image: `${GP_ASSETS}/G.P.Pharmacy-College4.jpg` },
        { title: 'Modern Laboratories', desc: 'Hands-on practical training with industry-standard equipment.', image: `${GP_ASSETS}/Pharmaceutics-lab.jpg` },
        { title: 'AC Library', desc: 'Air-conditioned library with vast resources for study and research.', image: `${GP_ASSETS}/G.P.-Pharmacy-College-Library.jpg` },
        { title: 'Separate Hostels', desc: 'Safe, comfortable hostel facilities for boys and girls.', image: `${GP_ASSETS}/G.P.Pharmacy-College28.jpg` },
        { title: 'Transport & Amenities', desc: 'Reliable college transport, purified water, and campus conveniences.', image: `${GP_ASSETS}/G.P.Pharmacy-College10.jpg` },
      ],
      leadership: [
        {
          name: 'Er. G. Ponnusamy',
          role: 'Chairman · GP Group of Institutions',
          image: `${GP_ASSETS}/G.P.Pharmacy-Chairman.jpg`,
          bio: 'Visionary educationist providing quality education since 1979 through ITI, arts & science, polytechnic, education and pharmacy colleges. His leadership established G.P. Pharmacy College as the first pharmacy institution in Tirupattur and Vellore District.',
        },
        {
          name: 'Prof. Dr. S. Thenmozhi',
          role: 'Principal · G.P. Pharmacy College',
          image: '/images/about/about-principal.png',
          bio: 'M.Pharm., Ph.D — Academic head responsible for institutional excellence and student outcomes.',
        },
      ],
    },
    courses: { published: true, heroTitle: 'Courses Offered', programs: [] },
    faculty: {
      published: true,
      heroTitle: 'Faculty & Staff',
      heroSubtitle: 'Experienced educators across pharmacy departments — committed to your success',
      members: [],
    },
    contact: {
      published: true,
      heroTitle: 'Contact Us',
      heroSubtitle: 'Talk to Admin · Counselling Code 889 · Jolarpet campus',
      address:
        'Vaniyambadi Main Road, Mandalavadi (Vill&Po), Jolarpet-635851, Tirupattur Taluk & District, TN',
      principal: 'Prof. Dr. S. Thenmozhi, M.Pharm., Ph.D',
      principalEmail: 'drthenmozhish@gmail.com',
      phones: [
        { display: '+91 94434 37487', tel: '+919443437487' },
        { display: '+91 95786 27535', tel: '+919578627535' },
        { display: '+91 94432 29324', tel: '+919443229324' },
        { display: '+91 63857 59996', tel: '+916385759996' },
        { display: '04179 299723', tel: '04179299723' },
      ],
      email: 'gppharmacycollege@gmail.com',
      hours: 'Mon – Sat · 9:00 AM – 5:00 PM',
    },
    campus: {
      published: true,
      heroTitle: 'Digital Campus',
      heroSubtitle: 'World-class infrastructure for pharmacy education',
      labsIntro:
        'Four dedicated labs for manufacturing practice, chemistry, pharmacology, and natural products — where theory becomes skill.',
      labs: [
        {
          id: 'pharmaceutics',
          index: '01',
          title: 'Pharmaceutics Lab',
          image: `${GP_ASSETS}/Pharmaceutics-lab.jpg`,
          body: 'This laboratory provides elementary knowledge about the manufacturing of pharmaceutical preparations. This lab is also utilized to teach about the dispensing of drugs in a hospital by a pharmacist and about community pharmacy practice. The lab is used for the preparation of aromatic waters, syrups, liniments, lozenges, lotions, tinctures etc.',
          focus: ['Aromatic waters', 'Syrups & liniments', 'Lozenges & lotions', 'Tinctures', 'Dispensing practice'],
        },
        {
          id: 'chemistry',
          index: '02',
          title: 'Pharmaceutical Chemistry Lab',
          image: `${GP_ASSETS}/G.P.Pharmacy-College10.jpg`,
          body: 'These well furnished laboratories provide facilities for practical training in pharmaceutical medicinal chemistry, synthesis and structural elucidation of medicinally important compounds. Practical training is also offered in organic chemistry with well designed experiments. Students are familiarized with various organic compounds by their nature, physical and chemical properties and usage in chemical reactions as well as in pharmaceutical industries.',
          focus: ['Medicinal chemistry', 'Synthesis', 'Structural elucidation', 'Organic experiments'],
        },
        {
          id: 'pharmacology',
          index: '03',
          title: 'Pharmacology Lab',
          image: `${GP_ASSETS}/G.P.Pharmacy-College12.jpg`,
          body: 'Pharmacology lab consists of equipment to investigate the activity of various drug samples, such as Rota Rod, Electro-convulsiometer, Analgesiometer, Histamine chamber and Actophotometer. Human Anatomy and Physiology of human body is also studied with the help of charts, models including human skeleton and various types of apparatus.',
          focus: ['Rota Rod', 'Electro-convulsiometer', 'Analgesiometer', 'Histamine chamber', 'Actophotometer'],
        },
        {
          id: 'pharmacognosy',
          index: '04',
          title: 'Pharmacognosy Lab',
          image: `${GP_ASSETS}/G.P.Pharmacy-College17.jpg`,
          body: 'Pharmacognosy is a specific discipline that deals with the rapid developments in the knowledge and utilization of medicinal substances of biological origin (plant, microorganism and animal products) used for human and veterinary purposes. The laboratory has various instruments like Soxhlet apparatus, Laminar Air Flow, Digital Balance, Calorimeter, UV cabinet.',
          focus: ['Soxhlet apparatus', 'Laminar Air Flow', 'Digital Balance', 'Calorimeter', 'UV cabinet'],
        },
      ],
      facilities: [
        { title: 'Smart Classrooms', desc: 'Interactive digital tools for dynamic, engaging lectures.', image: `${GP_ASSETS}/G.P.Pharmacy-College26.jpg` },
        { title: 'AC Central Library', desc: 'Vast collection of pharmacy texts, journals, and research material.', image: `${GP_ASSETS}/G.P.Pharmacy-College1.jpg` },
        { title: 'Separate Hostels', desc: 'Secure, comfortable boys & girls hostel facilities.', image: `${GP_ASSETS}/G.P.Pharmacy-College28.jpg` },
        { title: 'College Transport', desc: 'Safe, reliable buses covering Jolarpet and surrounding areas.', image: `${GP_ASSETS}/G.P.Pharmacy-College10.jpg` },
        { title: 'Computer Center', desc: 'Modern systems with pharmacy software and internet access.', image: `${GP_ASSETS}/G.P.Pharmacy-College22.jpg` },
        { title: 'Seminar Halls', desc: 'Spacious halls for conferences, workshops, and guest lectures.', image: `${GP_ASSETS}/G.P.Pharmacy-College12.jpg` },
      ],
    },
  },
  admissions: {
    published: true,
    heroTitle: 'Talk to Admin',
    heroSubtitle: 'Call or WhatsApp for Code 889 guidance — no online application on this site',
    fee: 500,
    counsellingCode: '889',
  },
  notices: [
    {
      id: 'notice-1',
      title: 'Counselling Code 889 — Admissions open',
      summary: 'Talk to Admin for D.Pharm, B.Pharm, M.Pharm and Pharm-D guidance.',
      date: '2026-09-10',
      category: 'admission',
      urgent: true,
      published: true,
      link: '/admissions',
    },
  ],
  events: [
    {
      id: 'campus-visit',
      title: 'Visit Campus — Jolarpet',
      summary: 'Tour labs, library and hostels. Call +91 94434 37487 to schedule a visit.',
      date: '2026-09-25',
      category: 'academic',
      published: true,
    },
    {
      id: 'skills-lab',
      title: 'Clinical Skills Workshop',
      summary: 'Hands-on case discussions and dispensing practice for final-year pharmacy students.',
      date: '2026-10-08',
      category: 'workshop',
      published: true,
    },
    {
      id: 'pharmacy-week',
      title: 'Pharmacy Week Orientation',
      summary: 'Department showcases, guest talk, and student competitions on campus.',
      date: '2026-10-22',
      category: 'seminar',
      published: true,
    },
  ],
  news: [
    {
      id: 'news-1',
      title: 'Admissions guidance for Counselling Code 889',
      excerpt:
        'Parents and students can talk to Admin for D.Pharm, B.Pharm, M.Pharm and Pharm-D programme guidance on the Jolarpet campus.',
      date: '2026-09-12',
      published: true,
      image: `${GP_ASSETS}/G.P-Pharmacy-College-home.jpg`,
    },
    {
      id: 'news-2',
      title: 'Campus labs ready for practical training',
      excerpt:
        'Pharmaceutics, chemistry, pharmacology and pharmacognosy labs support hands-on pharmacy education aligned to PCI & AICTE standards.',
      date: '2026-09-05',
      published: true,
      image: `${GP_ASSETS}/Pharmaceutics-lab.jpg`,
    },
  ],
  placements: {
    published: true,
    heroTitle: 'Placement Portal',
    stats: [
      { label: 'Counselling Code', value: '889' },
      { label: 'Career Guidance', value: 'PDF' },
      { label: 'Office', value: '94434 37487' },
      { label: 'Established', value: '2019' },
    ],
    openings: [],
    recruiters: [],
    placedBatches: [],
  },
  research: {
    published: true,
    heroTitle: 'Research & Innovation',
    heroSubtitle:
      'Advancing pharmaceutical sciences through discovery, collaboration & industry partnerships',
    stats: [
      { label: 'Departments', value: 'Core labs' },
      { label: 'Programs', value: 'UG · PG · Pharm-D' },
      { label: 'Approvals', value: 'AICTE · PCI' },
      { label: 'Affiliation', value: 'TN MGR' },
    ],
    publications: [
      {
        year: '2025',
        title: 'Development of sustained-release matrix tablets for antihypertensive agents',
        meta: 'International Journal of Pharmacy & Pharmaceutical Sciences · Dr. S. Thenmozhi et al.',
      },
      {
        year: '2025',
        title: 'RP-HPLC method for simultaneous estimation of fixed-dose combinations',
        meta: 'Asian Journal of Pharmaceutical Analysis · Pharmaceutical Analysis Dept.',
      },
      {
        year: '2024',
        title: 'Regulatory pathways for biosimilars in India: A comprehensive review',
        meta: 'Journal of Pharmaceutical Regulatory Affairs · Regulatory Affairs Dept.',
      },
      {
        year: '2024',
        title: 'Phytochemical screening and antimicrobial activity of medicinal plants',
        meta: 'Research Journal of Pharmacy & Technology · Pharmacognosy Lab',
      },
    ],
    projects: [
      {
        eyebrow: 'Ongoing',
        title: 'Novel Drug Delivery Systems',
        desc: 'Development of lipid-based nanoparticles for poorly soluble drugs.',
        tag: 'M.Pharm',
      },
      {
        eyebrow: 'Completed',
        title: 'Phytopharmaceutical Standardization',
        desc: 'Quality markers and standardization of traditional medicinal formulations.',
        tag: '2024',
      },
      {
        eyebrow: 'Ongoing',
        title: 'Bioanalytical Method Development',
        desc: 'LC-MS/MS methods for therapeutic drug monitoring in clinical samples.',
        tag: 'Analysis',
      },
    ],
  },
  achievements: [],
  gallery: [],
};

function clone(obj) {
  return JSON.parse(JSON.stringify(obj));
}

function mergeDefaults(current) {
  if (!current.users?.length) current.users = [];
  if (!current.site) current.site = clone(DEFAULTS.site);
  else {
    for (const key of Object.keys(DEFAULTS.site)) {
      if (current.site[key] === undefined || current.site[key] === null) {
        current.site[key] = clone(DEFAULTS.site[key]);
      }
    }
  }
  if (!current.website) current.website = clone(DEFAULTS.website);
  if (!current.website.contact) current.website.contact = clone(DEFAULTS.website.contact);
  if (!current.website.campus) current.website.campus = clone(DEFAULTS.website.campus);
  else if (!current.website.campus.facilities) {
    current.website.campus.facilities = clone(DEFAULTS.website.campus.facilities);
  }
  if (!current.website.about) current.website.about = clone(DEFAULTS.website.about);
  else {
    for (const key of Object.keys(DEFAULTS.website.about)) {
      if (current.website.about[key] === undefined || current.website.about[key] === null) {
        current.website.about[key] = clone(DEFAULTS.website.about[key]);
      }
    }
    if (!current.website.about.highlights?.length) {
      current.website.about.highlights = clone(DEFAULTS.website.about.highlights);
    }
    if (!current.website.about.leadership?.length) {
      current.website.about.leadership = clone(DEFAULTS.website.about.leadership);
    }
    if (!current.website.about.discoverProse?.length) {
      current.website.about.discoverProse = clone(DEFAULTS.website.about.discoverProse);
    }
  }
  if (!current.admissions) current.admissions = clone(DEFAULTS.admissions);
  if (!current.placements) current.placements = clone(DEFAULTS.placements);
  if (!current.research) current.research = clone(DEFAULTS.research);
  else {
    for (const key of Object.keys(DEFAULTS.research)) {
      if (current.research[key] === undefined || current.research[key] === null) {
        current.research[key] = clone(DEFAULTS.research[key]);
      }
    }
    if (!current.research.publications?.length) {
      current.research.publications = clone(DEFAULTS.research.publications);
    }
    if (!current.research.projects?.length) {
      current.research.projects = clone(DEFAULTS.research.projects);
    }
  }
  if (!Array.isArray(current.notices)) current.notices = [];
  if (!Array.isArray(current.events)) current.events = [];
  if (!Array.isArray(current.news)) current.news = [];
  if (!current.news.length) current.news = clone(DEFAULTS.news);
  if (!Array.isArray(current.achievements)) current.achievements = [];
  if (!Array.isArray(current.gallery)) current.gallery = [];
  if (!current.notices.length) current.notices = clone(DEFAULTS.notices);
  if (!current.events.length) current.events = clone(DEFAULTS.events);
  if (!current.website.contact) current.website.contact = clone(DEFAULTS.website.contact);
  if (!current.website.campus) current.website.campus = clone(DEFAULTS.website.campus);
  const hp = current.website?.homepage;
  const defHp = DEFAULTS.website.homepage;
  if (hp && defHp) {
    for (const key of Object.keys(defHp)) {
      if (hp[key] === undefined || hp[key] === null) hp[key] = clone(defHp[key]);
    }
  }
  return current;
}

export function loadStore() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DATA_FILE)) {
    const initial = mergeDefaults(clone(DEFAULTS));
    fs.writeFileSync(DATA_FILE, JSON.stringify(initial, null, 2));
    return initial;
  }
  const parsed = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  return mergeDefaults(parsed);
}

export function saveStore(data) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  data.updatedAt = new Date().toISOString();
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
  return data;
}

function useNetlifyBlobs() {
  return (
    process.env.USE_NETLIFY_BLOBS === '1' ||
    process.env.NETLIFY === 'true' ||
    Boolean(process.env.AWS_LAMBDA_FUNCTION_NAME) ||
    Boolean(process.env.NETLIFY_BLOBS_CONTEXT) ||
    Boolean(process.env.BLOBS_CONTEXT)
  )
}

function isLambda() {
  return Boolean(process.env.AWS_LAMBDA_FUNCTION_NAME)
}

let memoryStore = null

async function getBlobStore() {
  const { getStore } = await import('@netlify/blobs')
  const opts = { name: 'gp-cms', consistency: 'strong' }
  const siteID = process.env.SITE_ID || process.env.NETLIFY_SITE_ID
  const token = process.env.NETLIFY_AUTH_TOKEN || process.env.BLOBS_TOKEN
  if (siteID && token) {
    opts.siteID = siteID
    opts.token = token
  }
  return getStore(opts)
}

/** Async load — Blobs on Netlify when available, else memory/filesystem. */
export async function loadStoreAsync() {
  if (useNetlifyBlobs()) {
    try {
      const blobStore = await getBlobStore()
      const data = await blobStore.get('cms-data', { type: 'json' })
      if (!data) {
        const initial = mergeDefaults(clone(DEFAULTS))
        initial.updatedAt = new Date().toISOString()
        try {
          await blobStore.setJSON('cms-data', initial)
        } catch {
          /* read-only / missing context — keep in memory */
        }
        memoryStore = initial
        return initial
      }
      memoryStore = mergeDefaults(data)
      return memoryStore
    } catch (err) {
      console.warn('[cms] Blobs unavailable:', err?.message || err)
    }
  }

  if (memoryStore) return memoryStore

  if (!isLambda()) {
    try {
      memoryStore = loadStore()
      return memoryStore
    } catch (err) {
      console.warn('[cms] filesystem load failed:', err?.message || err)
    }
  }

  memoryStore = mergeDefaults(clone(DEFAULTS))
  memoryStore.updatedAt = new Date().toISOString()
  return memoryStore
}

/** Async save — Blobs when possible; always updates in-memory for warm lambdas. */
export async function saveStoreAsync(data) {
  data.updatedAt = new Date().toISOString()
  memoryStore = data

  if (useNetlifyBlobs()) {
    try {
      const blobStore = await getBlobStore()
      await blobStore.setJSON('cms-data', data)
      return data
    } catch (err) {
      console.warn('[cms] Blobs save skipped:', err?.message || err)
      if (isLambda()) return data
    }
  }

  if (!isLambda()) {
    try {
      return saveStore(data)
    } catch (err) {
      console.warn('[cms] filesystem save failed:', err?.message || err)
    }
  }

  return data
}

export function getPublicContent(data) {
  const copy = clone(data);
  delete copy.users;
  copy.notices = (copy.notices || []).filter((item) => item.published !== false);
  copy.events = (copy.events || []).filter((item) => item.published !== false);
  copy.news = (copy.news || []).filter((item) => item.published !== false);
  copy.achievements = (copy.achievements || []).filter((item) => item.published !== false);
  copy.gallery = (copy.gallery || []).filter((item) => item.published !== false);
  return copy;
}
