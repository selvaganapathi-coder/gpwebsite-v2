import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

function resolveDirname() {
  try {
    if (typeof import.meta?.url === 'string' && import.meta.url) {
      return path.dirname(fileURLToPath(import.meta.url))
    }
  } catch {
    /* bundled CJS */
  }
  return path.join(process.cwd(), 'server')
}

const __dirname = resolveDirname()
const UPLOAD_DIR = path.join(__dirname, 'uploads')

function useNetlifyBlobs() {
  return (
    process.env.USE_NETLIFY_BLOBS === '1' ||
    process.env.NETLIFY === 'true' ||
    Boolean(process.env.AWS_LAMBDA_FUNCTION_NAME) ||
    Boolean(process.env.NETLIFY_BLOBS_CONTEXT) ||
    Boolean(process.env.BLOBS_CONTEXT)
  )
}

async function saveToBlobs(file) {
  const safeName = `${Date.now()}-${file.originalname.replace(/[^a-zA-Z0-9._-]/g, '-')}`
  try {
    const blobStore = await getUploadBlobStore()
    await blobStore.set(safeName, file.buffer, {
      metadata: { contentType: file.mimetype || 'application/octet-stream' },
    })
    return `/uploads/${safeName}`
  } catch (err) {
    // Fallback: data URL so admin still works without Blobs credentials
    const b64 = file.buffer.toString('base64')
    const mime = file.mimetype || 'image/jpeg'
    console.warn('[cms] upload Blobs failed, using data URL:', err?.message || err)
    return `data:${mime};base64,${b64}`
  }
}

async function getUploadBlobStore() {
  const { getStore } = await import('@netlify/blobs')
  const opts = { name: 'gp-uploads', consistency: 'strong' }
  const siteID = process.env.SITE_ID || process.env.NETLIFY_SITE_ID
  const token = process.env.NETLIFY_AUTH_TOKEN || process.env.BLOBS_TOKEN
  if (siteID && token) {
    opts.siteID = siteID
    opts.token = token
  }
  return getStore(opts)
}

export function ensureUploadDir() {
  if (useNetlifyBlobs()) return
  fs.mkdirSync(UPLOAD_DIR, { recursive: true })
}

export async function uploadImage(file, baseUrl) {
  const cloudName = process.env.CLOUDINARY_CLOUD_NAME
  const apiKey = process.env.CLOUDINARY_API_KEY
  const apiSecret = process.env.CLOUDINARY_API_SECRET

  if (cloudName && apiKey && apiSecret) {
    return uploadToCloudinary(file, cloudName, apiKey, apiSecret)
  }

  if (useNetlifyBlobs()) {
    return saveToBlobs(file)
  }

  return saveLocal(file, baseUrl)
}

export async function getUploadedFile(name) {
  const safe = path.basename(name)
  if (useNetlifyBlobs()) {
    try {
      const blobStore = await getUploadBlobStore()
      const meta = await blobStore.getMetadata(safe)
      if (!meta) return null
      const body = await blobStore.get(safe, { type: 'arrayBuffer' })
      if (!body) return null
      return {
        body: Buffer.from(body),
        contentType: meta.metadata?.contentType || 'application/octet-stream',
      }
    } catch {
      return null
    }
  }

  const target = path.join(UPLOAD_DIR, safe)
  if (!fs.existsSync(target)) return null
  return {
    body: fs.readFileSync(target),
    contentType: guessType(safe),
  }
}

function guessType(name) {
  if (/\.png$/i.test(name)) return 'image/png'
  if (/\.webp$/i.test(name)) return 'image/webp'
  if (/\.gif$/i.test(name)) return 'image/gif'
  return 'image/jpeg'
}

async function uploadToCloudinary(file, cloudName, apiKey, apiSecret) {
  const timestamp = Math.round(Date.now() / 1000)
  const folder = process.env.CLOUDINARY_UPLOAD_FOLDER || 'gp-pharmacy'

  const params = new URLSearchParams({
    timestamp: String(timestamp),
    folder,
    transformation: 'f_auto,q_auto',
  })

  const signature = await import('crypto').then(({ createHmac }) =>
    createHmac('sha1', apiSecret).update(params.toString()).digest('hex'),
  )

  const body = new FormData()
  body.append('file', new Blob([file.buffer], { type: file.mimetype }), file.originalname)
  body.append('api_key', apiKey)
  body.append('timestamp', String(timestamp))
  body.append('signature', signature)
  body.append('folder', folder)
  body.append('transformation', 'f_auto,q_auto')

  const response = await fetch(`https://api.cloudinary.com/v1_1/${cloudName}/image/upload`, {
    method: 'POST',
    body,
  })

  const data = await response.json()
  if (!response.ok || !data.secure_url) {
    throw new Error(data.error?.message || 'Cloudinary upload failed.')
  }
  return data.secure_url.replace('/upload/', '/upload/f_auto,q_auto/')
}

function saveLocal(file, _baseUrl) {
  ensureUploadDir()
  const safeName = `${Date.now()}-${file.originalname.replace(/[^a-zA-Z0-9._-]/g, '-')}`
  const target = path.join(UPLOAD_DIR, safeName)
  fs.writeFileSync(target, file.buffer)
  return `/uploads/${safeName}`
}
